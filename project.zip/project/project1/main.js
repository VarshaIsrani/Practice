var u = require('underscore');
console.log(u.first([5, 4, 3, 2, 1]));
console.log(u.last([5, 4, 3, 2, 1]));