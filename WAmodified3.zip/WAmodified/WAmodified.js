$(function() {
	function viewModel(){
		var self = this;
		self.tableDetails= ko.observableArray();
		
		self.Wrapper = ko.observable(true);
		self.bookDetailsDisplay = ko.observable(false);
		self.authorDetailsDisplay = ko.observable(false);
		self.bookDetailsAdd = ko.observable(false);
		self.authorDetailsAdd = ko.observable(false);

		self.isbn=ko.observable();
		self.title=ko.observable();
		self.author=ko.observable();
		self.price=ko.observable();
		self.availableOn=ko.observable([]);
			
		self.empid=ko.observable();
		self.name=ko.observable();
		self.email=ko.observable();
		self.website=ko.observable();
		self.department=ko.observable();
		self.skills=ko.observableArray([]);

		self.newskills=ko.observableArray(['HTML', 'Python', 'CSS', 'JS']);
		self.newskills2=ko.observableArray();

		self.availOn=ko.observableArray(['Amazon', 'Flipkart', 'Snapdeal', 'Kindle']);
		self.availOn2=ko.observableArray();
			
		
		$.ajax({
			url : 'http://172.27.12.104:3000/book/list',
			dataType : 'json',
			type : "GET",
			success : function(data){
				console.log(data);
				self.tableDetails(data);
			}
		});	

		

		self.displayBook = function(data){
			self.bookDetailsDisplay(true);
			self.Wrapper(false);
			self.authorDetailsDisplay(false);
			self.bookDetailsAdd(false);
			self.authorDetailsAdd(false);
			
			self.isbn(data.isbn);
			self.title(data.title);
			self.author(data.author);
			self.price(data.price);
			self.availableOn(data.availableOn);
		}

		self.updateBook = function(){
			//implement POST for Update book
			var updatedBook = { "isbn" : self.isbn, "title" : self.title,  "author" : self.author,  "price":  self.price, "availableOn": self.availOn2};
			console.log('updatedBook' + updatedBook);
			$.ajax({
				url : 'http://172.27.12.104:3000/book/update',
				dataType : 'json',
				data : updatedBook,
				type: "PUT",
				success : function(data){
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in updating the book details');
				}
			});	
		}

		self.deleteBook = function(){
			//implement DELETE for Update book/ use data if POST method
			var deleteBook = {isbn: self.isbn()};
			$.ajax({
				url : 'http://172.27.12.104:3000/book/remove',
				dataType : 'json',
				data : deleteBook,
				type: "DELETE" ,
				success : function(data){
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in deleting the book');
				}
			});	
		}

		function initBookForm() {
			self.isbn('');
			self.title('');
			self.author('');
			self.price('');
			self.availableOn([]);				
		}

		self.addBookView = function(){
			self.Wrapper(false);
			self.bookDetailsDisplay(false);
			self.authorDetailsDisplay(false);
			self.bookDetailsAdd(true);
			self.authorDetailsAdd(false);
			initBookForm();
		}
		
		self.addBook = function() {
			//implement POST for Add book
			var addedBook = { "isbn" : self.isbn, "author" : self.author, "title" : self.title,  "price":  self.price, "availableOn": self.availOn2};
			console.log('addedBook'+ addedBook);
			$.ajax({
				url : 'http://172.27.12.104:3000/book/new',
				dataType : 'json',
				data : addedBook,
				type: "POST" ,
				success : function(data){
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in adding the book details');
				}
			});	
				//location.reload();
		}


		self.displayAuthor = function(data){
			self.authorDetailsDisplay(true);
			self.bookDetailsDisplay(false);
			self.Wrapper(false);
			self.bookDetailsAdd(false);
			self.authorDetailsAdd(false);
			
			var author = { "name" : data.author };
			$.ajax({
				url : 'http://172.27.12.104:3000/author/byname',
				dataType : 'json',
				data : author ,
				type: "POST" ,
				success : function(data){
					console.log(data);
					self.empid(data.empid);
					self.name(data.name);
					self.email(data.email);
					self.website(data.website);
					self.department(data.department);
					self.skills(data.skills);
				}
			});	
		}

		self.updateAuthor = function(){
			//implement POST for Update author
			var updatedAuthor = { "name" : self.name, "empid" : self.empid, "email" : self.email, "website":  self.website, "department": self.department, "skills": self.newskills2};
			console.log('updatedAuthor'+ updatedAuthor.skills);
			$.ajax({
				url : 'http://172.27.12.104:3000/author/update',
				dataType : 'json',
				data : updatedAuthor,
				type: "PUT" ,
				success : function(data){
					console.log(data);
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in updating the author details');
				}
			});	
				//location.reload();		
		}
		
		
		self.deleteAuthor = function(){
			//implement DELETE for Update author
			var deleteAuthor = {empid: self.empid()};
			$.ajax({
				url : 'http://172.27.12.104:3000/author/remove',
				dataType : 'json',
				data : deleteAuthor,
				type: "DELETE" ,
				success : function(data){
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in deleting the author');
				}
			});			
		}

		function initAuthorForm() {
			self.empid('');
			self.name('');
			self.email('');
			self.website('');
			self.department('');
			self.skills([]);	
		}		


		self.addAuthorView = function(){
			self.Wrapper(false);
			self.bookDetailsDisplay(false);
			self.authorDetailsDisplay(false);
			self.bookDetailsAdd(false);
			self.authorDetailsAdd(true);
			initAuthorForm();
		}
		
		self.addAuthor = function() {
			//implement POST for Add author
			var addedAuthor = { "name" : self.name, "empid" : self.empid, "email" : self.email, "website":  self.website,"department": self.department, "skills": self.newskills2};
			console.log('addedAuthor'+ addedAuthor);
			$.ajax({
				url : 'http://172.27.12.104:3000/author/new',
				dataType : 'json',
				data : addedAuthor,
				type: "POST" ,
				success : function(data){
					alert('Author has been added successfully', data);
					location.reload();
				},
				error: function(error){
					console.log(error);
					alert('There was an error in adding the author details');
				}
			});	
		}

		self.goToMain = function() {
			location.reload();
		}
	}

	ko.applyBindings(new viewModel());
});



		
		