<!DOCTYPE>
<html>
<head>
	<title>Validate Inputs</title>
	<style>
		body {
			font-family: Calibri;
		}
		.content {
			text-align: center;
		}
		.content table {
			margin: 0px auto;
		}
		.green {
			color: green;
		}
		.red {
			color: red;
		}
	</style>

	<script>
	// Hey...
	// Write code here
	
	
	// Validate the inputs on this page.
	function ValidateForm() {
		var regex;
        //validate name
        var name = jQuery("#name").val();
        var namemessage = jQuery("#namemessage");
        regex = /\b[a-zA=Z]+\b/;
        if (regex.test(name)) {
            jQuery("namemessage").html('Valid');
            jQuery("namemessage").addClass("green");
        }
        
        else {
            jQuery("namemessage").html("not Valid");
            jQuery("namemessage").addClass("red");
	}

        //validate age
         var age = jQuery("#age").val();
        var agemessage = jQuery("#agemessage");
        regex = /\b[0-9]+\b/;
        if (regex.test(age)) {
            jQuery("agemessage").html("Valid");
            jQuery("agemessage").addClass("green");
        }
        
        else {
            jQuery("agemessage").html("not Valid");
            jQuery("agemessage").addClass("red");
	}
    }
        
	// Reset any messages that were displayed.
	function ResetMessage() {

	}
	</script>
</head>
<body>
	<div class="content">
		<h1>Validate Inputs</h1>
		<form>
			<div>
				<span>Name:</span>
				<input id="name" type="text" />
				<span name='message' id="namemessage"></span>
			</div>
			<br / >
			<div>
				<span>Age:</span>
				<input id="age" type="text" />
				<span name='message' id="agemessage"></span>
			</div>
			<br / >
			<div>
				<input type="button" value="Validate Inputs" onclick="ValidateForm();">
				<input type="button" value="Reset Messages" onclick="ResetMessage();">
			</div>
		</form>
	</div>
</body>
</html>