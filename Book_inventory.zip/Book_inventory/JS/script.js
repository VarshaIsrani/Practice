/**KnockOut View Model*/
function appViewModel(){
	var self=this;
	self.showList=ko.observable(true);
	self.showAddBook=ko.observable(false);
	self.showAddAuthor=ko.observable(false);
	self.showBookDisplay=ko.observable(false);
	self.showAuthorDisplay=ko.observable(false);
	self.showEditBook=ko.observable(false);
	self.showEditAuthor=ko.observable(false);
	self.successMessage=ko.observable();
	self.showAlert=ko.observable(false);
	self.bookArray=ko.observableArray();
	
	/**Book attributes*/
	self.isbn=ko.observable();
	self.title=ko.observable();
	self.author= ko.observable();
	self.price=ko.observable().extend({number:true });
	self.isAvailable= ko.observableArray();
	
	/**Employee attributes*/
	self.empid=ko.observable().extend({number:true });
	self.name=ko.observable();
	self.email=ko.observable().extend({email: true});
	self.skills=ko.observableArray();
	self.department=ko.observable().extend({number:true });
	self.website=ko.observable();
	
	/**This is the Function to load the data from server through ajax GET method*/
	self.loadAjaxData=function(){
		$.ajax({
			type: "get",
			url:"http://172.27.12.104:3000/book/list",
			contentType:'application/json',
			success: function (data) {
				ko.mapping.fromJS(data,{}, self.bookArray);
				}
			});
	}
	
	self.loadAjaxData();
	
	/**Function to display Add-Book Form on button click*/
	self.addBookForm=function(){
		self.showAddBook(true);
		self.showList(false);
		self.showEditBook(false);
		self.showBookDisplay(false);
		self.showAddAuthor(false);
		self.showAuthorDisplay(false);
		self.showEditBook(false);
		self.showEditAuthor(false);
		self.isbn("");
		self.title("");
		self.author("");
		self.price("");
		self.showAlert(false);	
	}
		
	/**Function to add a new book by ajax POST method 
	*@ param-{isbn,title,author,price,availableOn}*/
	self.addBook=function(){
	console.log(self.isAvailable());
		$.ajax({
			url:"http://172.27.12.104:3000/book/new",
			type: "post",
			contentType:'application/json',
			data:ko.toJSON({"isbn":self.isbn,
			"title":self.title,
			"author":self.author,
			"price":self.price,
			"availableOn":self.isAvailable}),
			success: function (result) {
			console.log(result.message);
		    self.successMessage(result.message);
			self.showAlert(true);	
				}
			});
				
	}
	
	/**Function to display book Information by Ajax POST request
	*@ param-{isbn}*/
	self.displayBookInfo=function(Book){
		self.showBookDisplay(true);
		self.showList(false);
		$.ajax({
			type: "post",
			url:"http://172.27.12.104:3000/book/byisbn",
			contentType:'application/json',
			data:{"isbn":Book.isbn},
			success: function (result) {
			self.showAlert(false);	
			console.log(result);
			console.log(result.availableOn);
			self.isbn(result.isbn);
			self.title(result.title);
			self.author(result.author);
			self.price(result.price);
			self.isAvailable(result.availableOn);
			}
		});
		
	}
	/**Function display editable form of the displayed entry */
	self.editBook=function(){
		self.showEditBook(true);
		self.showBookDisplay(false);
		self.showAlert(false);	
	}
	
	/**Function to edit the Book information by Ajax POST method
	*@ param-{isbn,title,author,price,availableOn*/
	self.updateBook=function(){
		$.ajax({
			type: "put",
			url:"http://172.27.12.104:3000/book/update",
			contentType:'application/json',
			data:ko.toJSON({
				"isbn":self.isbn,
				"title":self.title,
				"author":self.author,
				"price":self.price,
				"availableOn":self.isAvailable }),
			success: function (result) {
				self.successMessage(result.message);
				self.showAlert(true);	
				console.log(result);
				}
			});
	}
	
	/**Function to delete the Book entry by Ajax POST method
	*@ param-{isbn}*/
	self.deleteBook=function(){
		$.ajax({
			type: "delete",
			url:"http://172.27.12.104:3000/book/remove",
			contentType:'application/json',
			data:{"isbn":self.isbn },
			success: function (result) {
				self.successMessage(result.message);
				self.showAlert(true);
				console.log(result);
				}
			});
	}
	
	/**Function to display Add Author form*/
	self.addAuthorForm=function(){
		self.showAddAuthor(true);
		self.showAddBook(false);
		self.showList(false);
		self.showEditBook(false);
		self.showBookDisplay(false);
		self.showBookDisplay(false);
		self.showAuthorDisplay(false);
		self.showEditBook(false);
		self.showEditAuthor(false);
		self.showAlert(false);
		self.empid("");
		self.name("");
		self.email("");
		self.department("");
		self.website("");
		self.skills();
	}
	
	/**Function to delete the Book entry by Ajax POST method
	*@ param{empid,name,email,department,website,skills}*/
	self.addAuthor=function(){
		$.ajax({
			url:"http://172.27.12.104:3000/author/new",
			type: "post",
			url:"http://172.27.12.104:3000/author/new",
			contentType:'application/json',
			data:ko.toJSON({
				"empid":self.empid,
				"name":self.name,
				"email":self.email,
				"department":self.department,
				"website":self.website,
				"skills":self.skills
				}),
			success: function (data) {
				self.successMessage(data.message);
				self.showAlert(true);
				console.log(data);
				}
			});
	}
	
	/**Function to display the author information by ajax POST method
	*@ param{name} */	
	self.displayAuthorInfo=function(author){
		self.showAuthorDisplay(true);
		self.showList(false);
		$.ajax({
				type: "POST",
				url:"http://172.27.12.104:3000/author/byname",
				contentType:'application/json',
				data:{"name":author.author},
				success: function (result) {
					self.showAlert(false);
					self.empid(result.empid);
					self.name(result.name);
					self.email(result.email);
					self.department(result.department);
					self.website(result.website);
					self.skills(result.skills);
					}
				});
	}
	
	/**Function to display Edit Author form*/
	self.editAuthor=function(){
		self.showEditAuthor(true);
		self.showAuthorDisplay(false);
		self.showAlert(false);
		self.showAddAuthor(false);
	}
	
	/**Function to edit the author information by ajax POST method
	*@ param{empid,name,email,website,department} */
	self.updateAuthor=function(){
		$.ajax({
			type: "PUT",
			url:"http://172.27.12.104:3000/author/update",
			contentType:'application/json',
			data:ko.toJSON({
				"empid":self.empid,
				"name":self.name,
				"email":self.email,
				"website":self.website,
				"department":self.department,
				"skills":self.skills
			}),
			   success: function (result) {
				console.log(result);
			   console.log(result.isbn);
			   self.successMessage(result.message);
			   self.showAlert(true);
			   }
			});
	}
	
	/**Function to delete the author information by ajax POST method
	*@ param{empdid}*/
	self.deleteAuthor=function(Book){
		$.ajax({
			type: "DELETE",
			url:"http://172.27.12.104:3000/author/remove",
			data:{"empid":self.empid},
			success: function (result) {
			self.successMessage(result.message);
			  self.showAlert(true);
			console.log(result);
				}
			});
	}
	
	/**Function to display the First View(Book Table) with updated data through ajax GET method*/
	self.homePage=function(){
	self.loadAjaxData();
	self.showList(true);
	self.showAddBook(false);
	self.showAddAuthor(false);
	self.showBookDisplay(false);
	self.showAuthorDisplay(false);
	self.showEditBook(false);
	self.showEditAuthor(false);
	self.showAlert(false);
	
	
	}
		
}

/**Applying knockout bindings */
ko.applyBindings(new appViewModel());
	
	
	
	
	
		
		
		


