module.exports = function (){
	return {
		frndName : "hi"
	}
};