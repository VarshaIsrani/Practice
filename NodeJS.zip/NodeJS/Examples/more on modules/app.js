var names = require('./name');

console.log(names.rajan());