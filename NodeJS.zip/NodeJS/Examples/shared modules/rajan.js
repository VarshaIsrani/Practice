var names = require('./name');
names.myName = "Rajan";
console.log("My name is " + names.myName);