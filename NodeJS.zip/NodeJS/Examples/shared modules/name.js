module.exports = {
	myName : ""
};