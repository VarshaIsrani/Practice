var a = null;
if(a == null) {
	console.log("hello");
}