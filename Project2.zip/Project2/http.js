var http = require('http');


//http.createServer(function madeRequest(req, res){
  //  res.writeHead(200, {"content-Type": "text/plain"});
//    res.write("Hello World");
//    res.end();
// }).listen(8080);
function madeRequest(req, res){
    res.writeHead(200, {"content-Type": "text/plain"});
    res.write("Node js Session 2 ");
    res.end();
    
}

http.createServer(madeRequest).listen(8080);

console.log("Server is started..");