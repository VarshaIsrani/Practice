require('./Prac1') //importing ./ => current dir

console.log(one);
console.log(two);
//console.log(mod)