var one = 1;
var two = 2;

global.one = one; // left side is object, rs is method or prop
//function associated with obj is known as method
global.two = two; //exporting

//module.exports.one = one;
//module.exports.two = two;  // it is an obj
//console.log(module.exports);


