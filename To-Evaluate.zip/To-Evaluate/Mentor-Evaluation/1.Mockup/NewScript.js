function ValidateForm() {
  
        //var email1 = $("#email").val();
        var emailmsg = jQuery("#emailmessage");
    

    regex = /\b[a-zA-Z]{3,8}\b/;
             
             if($("#email").val()=="") { 
                console.log("I exist");
             }
             else{
                console.log("Im fooling you");
             }

}