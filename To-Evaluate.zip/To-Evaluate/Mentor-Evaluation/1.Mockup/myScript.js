function ValidateForm() {
        var regex;
        var isValid = true;
        var isName = true;
        var isPassword = true;
        var isEmail = true;
        var isEmp = true;
        var isError = false;

        var errmsg = jQuery("#errmessage");
        
        var name1 = $("#name").val();
        var namemsg = jQuery("#namemessage");
        console.log(name1);
        

        regex = /\b[a-zA-Z]{3,8}\b/;
         if(regex.test(name1)) { 
         }
        else {
                isName = false;
                isValid = false;
        }
        

        var pwd1 = $("#pwd").val();
        var pwdmsg = jQuery("#pwdmessage");
        var conp1 = $("#conp").val();
        regex = /\b[a-zA-Z0-9]{8,}\b/;

        if (regex.test(pwd1) && pwd1===conp1) { 
        }
        else {
            isPassword = false;
            isValid = false;
        }

        var email1 = $("#email").val();
        var emailmsg = jQuery("#emailmessage");
        regex = /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/;
        
        if (regex.test(email1)) { 
        }
        else {
            isValid = false;
            isEmail = false;
        }

        var emp1 = $("#emp").val();
        var empmsg = jQuery("#empmessage");
        regex = /\b[a-zA-Z]+\b/;
        
        if (regex.test(emp1)) {

        }
        else {
            isValid = false;
            isEmp = false;
        }   

var accessL = $('input[name="accessLevel"]:checked').val();
var fname1 = $("#fname").val();
var lname1 = $("#lname").val();
var loc1 = $("#loc").val();
var abt1 = $("#abt").val();



var file = $("#upload").val();
file.onchange = function() {
$("#idfile").val() = $("#upload").val();   
};

  



         if(name1 == " " || email1 == " " || pwd1 == " " || emp1 == " ")
        { 
            console.log("hi");
            errmsg.html("Please fill the required fields");
        }

        else{
            if (isValid === false){
                if(isName === false){
                namemsg.html("Username is invalid");
                }
                if(isEmail === false){
                emailmsg.html("Email Id is invalid");
                }
                if(isPassword === false){
                pwdmsg.html("Password is invalid");
                }
                if(isEmp === false){
                empmsg.html("Employee Id is invalid");
                }
            }
            else{
                 alert("Username:"+name1+"\nEmail Id:"+email1+"\nAccess Level:"+accessL+"\nFirst Name:"+fname1+"\nLast Name:"+lname1+"\nLocation:"+loc1+"\nAbout:"+abt1);
            }

        }

}

function ResetMessage() {
     document.getElementById("myForm").reset();
     document.getElementById("myForm1").reset();
}