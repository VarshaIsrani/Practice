
//Collection of the animals list along with their usernames
var animals = [
{username: 'duck'}, 
{username: 'camel'},
{username: 'dog'},
{username: 'cat'},
{username: 'lion'}
];

//Creating a Friendlist by creating a variable friends and assigning it to empty data structure
var friends = [];
//Adding username value of collection animals to the data structure friends
friends.push(animals[2].username);
friends.push(animals[4].username);
console.log(friends); // Looks like,  ["dog", "lion"]


//Creating Relationships Object
var relationships = { };
//Adding friends data structure to the object relationships
relationships.friends = friends;
console.log(relationships);
//The length of object relationships is undefined


//Adding matches array to the object relationships
var matches = [];
relationships.matches = matches;
//Adding username to array matches using dot functionality since it is nested inside object relationships
relationships.matches.push('donkey');


//Looping through animals collection and adding relationships object
for (var i = 0; i < animals.length; i++) {
	animals[i].relationships = relationships;
}
//Outputs animals collection with properties username and relationships
console.log(animals);
console.log(animals.length);


