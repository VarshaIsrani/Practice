//Function AnimalTestUser with single parameter																					
function AnimalTestUser(username){
	//declaration of property
	var otherArgs = [];
	//Check if the function AnimalTestUser has more than one argument
	if(arguments.length > 1) {
		//If yes create a property otherArgs with array type including other arguments
		for (var i=1; i< arguments.length; i++) {
			otherArgs.push(arguments[i]);
		}
	}
	//Returns object with username and otherArgs properties
	var animal = {
		username: username,
		otherArgs: otherArgs
	};
	return animal;
}

var testSheep = AnimalTestUser('CottonBall', {'loves dancing': true}, [1,2,3] );
console.log(testSheep); //{ username: 'CottonBall', otherArgs: [ {'loves dancing': true}, [1,2,3] ] }


//Creating constructor AnimalCreator, Four parameters based and one empty array (friends[]) initialization
function AnimalCreator(username,species,tagline,noises)
{
this.username=username;
this.species=species;
this.tagline=tagline;
this.noises=noises;
this.friends= [];
}

//Creating animal objects using using above constructor
var sheep = new AnimalCreator('Cloud', 'Sheep', 'You can count on me!', ['baahhh', 'arrgg', 'chewchewchew']);
console.log(sheep);

var horse = new AnimalCreator('Stallion', 'Horse', 'Here I am', ['neigh', 'eehh']);
console.log(horse);

var cow = new AnimalCreator('Moose', 'Cow', 'Let me moo', ['moo', 'gaaan']);
console.log(cow);

var goat = new AnimalCreator('Greece', 'Goat', 'Tick tok tik', ['bleat', 'meh']);
console.log(goat)


//Created multiple Animal Objects to help in below functions

/*function addFriend(animalOne, animalTwo){
	animalOne.friends.push(animalTwo.username);
}*/


//Modified above commented function to include only username of friend Animal
function addFriend(animalOne, animalTwo){
	animalOne.friends.push(animalTwo.username);
}

addFriend(sheep,cow);
console.log(sheep);

addFriend(cow,horse);
addFriend(cow, goat);
console.log(cow);

addFriend(horse,cow);
addFriend(horse,goat);
console.log(horse);

addFriend(goat,sheep);
addFriend(goat,horse);
console.log(goat);

//All animals now have at least one friend because of above function calls using animalOne and animlaTwo



//myFarm collection/array of animal objects
var myFarm = [sheep, cow, goat];
console.log(myFarm);
 
 function addMatchesArray(farm) {
	for(var i=0; i<farm.length; i++){
		farm[i].matches=[];
	}
}
addMatchesArray(myFarm);
//Initiated the matches array property for all Animal objects inside myFarm
console.log(myFarm[0]);


//Adding first friend to the matches array
function giveMatches(farm) {
	for (var i = 0; i<farm.length; i++) {
		farm[i].matches.push(farm[i].friends[0]);
	}
}
giveMatches(myFarm);
console.log(myFarm);  
// { username: 'Moose', species: 'Cow', tagline: 'Let me moo', noises: ['moo', 'gaaan'], friends: ['Stallion', 'Greece'], matches: ['Stallion']
   


